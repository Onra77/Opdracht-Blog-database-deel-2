<?php
    include("db.php");
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="styles/style.css">
    <title>Blog</title>
    <?php include 'thema.html'; ?>
</head>