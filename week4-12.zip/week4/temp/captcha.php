<?php
//echo $cap = (rand(100,1000));
?> 
<input placeholder="Wat is de code?" type="text" name="captcha">
<input type=hidden name="cap" value="<?php echo $cap;?>"
<

