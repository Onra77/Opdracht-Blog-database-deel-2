User stories:
Code
User story
W4-01
Als een Blogger wil ik een artikel aan één categorie kunnen koppelen zodat mijn lezers sneller artikelen kunnen vinden rondom een bepaald thema
W4-02
Als een Lezer wil ik alleen de artikelen in een bepaalde categorie kunnen selecteren zodat ik gericht alle artikelen over een bepaald thema kan lezen
W4-03
Als een Blogger wil ik zelf categorieën kunnen toevoegen zodat ik niet afhankelijk ben van de developer die mijn blog heeft ontwikkeld
W4-04
Als een Blogger wil ik ook meerdere categorieën kunnen koppelen aan een artikel zodat ik me niet hoef te beperken tot één thema

Optionele user stories

Code
User story
W4-05
Als een Blogger wil ik de tekst in het artikel kunnen formatteren (bijv. vet gedrukt of cursief maken) zodat ik duidelijker mijn boodschap kan overbrengen
Tip: maak hierbij gebruik van een standaard Javascript library
W4-06
Als een Blogger wil ik een afbeeldingen in een artikel kunnen plaatsen zodat ik duidelijker mijn boodschap kan overbrengen


https://www.youtube.com/watch?v=4ZBTeqSuBrk

