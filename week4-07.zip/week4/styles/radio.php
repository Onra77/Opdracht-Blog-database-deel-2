<table  id="gods" border="3" bgcolor="05fbfc">
<tr>
 <th style="text-align:center">Thema</th>
</tr>
<tr>
<th style="text-align:left"> <input type="radio" name="chooseone" value="health" id="health" onclick="health()"><label for="health" >Health</label><br></th>
</tr>
<tr>
<th style="text-align:left"> <input type="radio" name="chooseone" value="ICT" id="ICT" onclick="ICT()"><label for="ICT">ICT</label><br></th>
</tr>
<tr>
<th style="text-align:left"> <input type="radio" name="chooseone" value="politic" id="politic" onclick="politic()"><label for="politic">Politic</label><br></th>
</tr>
<tr>
<th style="text-align:left"> <input type="radio" name="chooseone" value="rest" id="rest" onclick="rest()"><label for="rest">Rest</label><br></th>
</tr>
  </table>